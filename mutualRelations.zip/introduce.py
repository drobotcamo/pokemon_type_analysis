# z = int(input("enter the first integer value for a range, no greater than 10\n"))
# while z > 10:
#     z = int(input("[ERROR, GREATER THAN 10] enter the first value for a range, no greater than 10\n"))

# x = range(z, 10)
# for y in x:
#     print(y)

# name = input("Please enter your name!\n")
# age = int(input("Please enter your age!\n"))
# yearsUntilHundred = 100 - age
# yearHundred = 2022 + yearsUntilHundred
# print(5*(name + ", you will be turning 100 in the year " + str(yearHundred) + "!\n"))

# thisDict = {
#     5: "frog",
#     False : "toad",
#     7: "FROG"
# }
# print(thisDict.get(False))

type1 = input("enter please:\n")
type1.capitalize()
print(type1)
